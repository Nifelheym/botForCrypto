<?php

$exchangers = array(
	"bch3k" => array("60сек","Xchange","ProstoCash","YChanger","MultiChange","NiceChange","4ange","365Cash","Банкомат"),
	"bch5k" => array("60сек","Xchange","ProstoCash","YChanger","MultiChange","NiceChange","4ange","YoChange","Банкомат","BaksMan","24PayBank","Platov","RamonCash","PayGet","AllCash","FastChange","El-Change","FlashObmen","Top-Exchange","F-Change","FastExchange","365Cash","Papa-Change"),
	"dash3k" => array("60сек","Xchange","ProstoCash","YChanger","MultiChange","NiceChange","4ange","YoChange","365Cash"),
	"dash5k" => array("60сек","Xchange","ProstoCash","YChanger","MultiChange","NiceChange","4ange","YoChange","Банкомат","BaksMan","24PayBank","Platov","RamonCash","PayGet","AllCash","FastChange","HoBit","N-Change","Bchange","F-Change","365Cash")
);

// echo count($exchangers['bch3k']);
echo $exchangers['bch3k'][0];
?>